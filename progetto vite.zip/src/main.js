import './style.css'

const response = await fetch("http://127.0.0.1:8090/api/collections/appuntozzi/records")
const data = response.json()
const postTest = document.getElementById("postTest")
const troll = document.getElementById("troll")
const stampa = document.getElementById("stampa")
var map = L.map('map').setView([-50, 20], 3);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

var popup = L.popup();

caricaMarkers();

async function onMapClick(e) {
    let name = prompt("Inserisci nome", "John Doe");
    if (name) {
      alert(name + " salvato con successo");
    } else {
    alert("Non hai inserito un nome");
    }

    await fetch("http://127.0.0.1:8090/api/collections/markers/records",{
    method:"POST",
    body:JSON.stringify({
      nome: name,
      pX: e.latlng.lat,
      pY: e.latlng.lng
    }),
   headers:{
     "Content-Type":"application/json"
    }
  });
  caricaMarkers();
}

async function caricaMarkers() {
  const res = await fetch("http://127.0.0.1:8090/api/collections/markers/records?fields=nome,pX,pY");
  const data = await res.json();
  const markers = data.items.map(item => ({
    nome: item.nome,
    pX: item.pX,
    pY: item.pY
  }));
  console.log(markers);
  markers.forEach(element => {
    L.marker([element.pX, element.pY]).addTo(map) .bindPopup(element.nome);
  });
  
}

map.on('click', onMapClick);